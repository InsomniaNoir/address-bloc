require 'spec_helper'
require_relative 'models/entry.rb'

RSpec.describe Entry do 

end